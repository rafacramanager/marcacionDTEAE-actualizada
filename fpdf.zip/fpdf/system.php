<?php
session_start();
include_once("../bd.php");

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['usuario'])) {
    echo "<script>window.location.href = 'panel.php';</script>";
    exit();
}

$codigo_usuario = $_SESSION['usuario'];
$usuario_autorizado = '$usuario';

// Verifica si el usuario ha iniciado sesión y tiene el nivel de acceso adecuado
if (!isset($_SESSION['nivel_acceso']) || $_SESSION['nivel_acceso'] != 1) {
    // Si el usuario no tiene el nivel de acceso adecuado, redirige al inicio
    echo "<script>window.location.href = '../panel.php';</script>";
    exit(); // Asegura que el script se detenga después de redirigir
}

// Verifica si el usuario tiene permiso para acceder a esta página
if ($codigo_usuario !== $usuario_autorizado) {
    echo "<script>window.location.href = '../panel.php';</script>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>System</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        h1,
        h2 {
            color: #333;
        }

        .container {
            max-width: 1200px;
            margin: auto;
            padding: 20px;
        }

        .search-container {
            margin-bottom: 20px;
        }

        .search-container input[type="text"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .search-container ul {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }

        .search-container ul li {
            padding: 10px;
            border-bottom: 1px solid #eee;
        }

        .search-container ul li:hover {
            background-color: #f9f9f9;
        }

        #selectBox {
            display: none;
        }

        .form-control {
            margin-bottom: 10px;
        }

        .alert {
            margin-top: 20px;
        }


        button {
            background: #fbca1f;
            font-family: inherit;
            padding: 0.6em 1.3em;
            font-weight: 900;
            font-size: 18px;
            border: 3px solid black;
            border-radius: 0.4em;
            box-shadow: 0.1em 0.1em;
            cursor: pointer;
        }

        button:hover {
            transform: translate(-0.05em, -0.05em);
            box-shadow: 0.15em 0.15em;
        }

        button:active {
            transform: translate(0.05em, 0.05em);
            box-shadow: 0.05em 0.05em;
        }
    </style>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <script src="https://kit.fontawesome.com/6305bb531f.js" crossorigin="anonymous"></script>
</head>

<body>
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="card-title text-center mb-0" style="font-size: 38px;">Panel de verdadero administrador</h1>
            <button onclick="window.location.href='../panel.php'" aria-label="Regresar al index">
                <i class="fa-solid fa-right-from-bracket" style="color: #ff0000;"></i> </button>
        </div>

        <h2 style="font-size: 28px;">Es un gusto volver a verte <span style="font-weight: bold;"><?php echo $usuario_autorizado; ?></span> creador del sistema.</h2>
        <form method="POST" action="" enctype="multipart/form-data" id="formularioBusqueda">
            <h3 style="font-size: 18px;" class="fw-bold" id="Texto">Seleccione un método para modificar los registros:</h3>


            <div class="mb-3">
                <div class="search-container">
                    <input type="text" id="searchInput" placeholder="Ingrese el nombre de un usuario" name="usuarios">
                    <ul id="results"></ul>
                </div>
                <!-- Esto son los elementos que se seleccionan según el search, esto no se muestra en pantalla -->
                <?php
                $sql = "SELECT codigo, usuario FROM usuarios";
                $resultado = mysqli_query($conn, $sql);
                ?>
                <select class="form-control" id="selectBox" name="usuarios">
                    <option value="" id="Select-form">Seleccione un empleado en específico</option>
                    <?php while ($fila = mysqli_fetch_assoc($resultado)) { ?>
                        <option value="<?php echo $fila['codigo']; ?>" <?php if (isset($_POST['usuarios']) && $_POST['usuarios'] === $fila['codigo']) echo 'selected'; ?>><?php echo $fila['usuario']; ?></option>
                    <?php } ?>
                </select>

                <!-- para que se vea el selectbox comentar el siguiente script  -->
                <script>
                    document.addEventListener("DOMContentLoaded", function() {
                        const selectBox = document.getElementById("selectBox");
                        selectBox.style.display = "none";
                    });
                </script>

                <!-- Estos son los filtros de dia y meses -->

                <div style="margin: 20px 2px 20px; display: flex; align-items: center;">
                    <input class="form-control" type="date" id="Select-date" name="fecha" style="margin-right: 5px;" placeholder="Seleccione una fecha en específico" <?php if (isset($_POST['fecha'])) echo 'value="' . htmlspecialchars($_POST['fecha']) . '"'; ?>>

                    <select class="form-control" id="Select-month" name="mes" style="margin-right: 5px;">
                        <option value="" <?php if (!isset($_POST['mes']) || $_POST['mes'] === '') echo 'selected'; ?>>Seleccione un mes en específico</option>
                        <option value="1" <?php if (isset($_POST['mes']) && $_POST['mes'] == '1') echo 'selected'; ?>>Enero</option>
                        <option value="2" <?php if (isset($_POST['mes']) && $_POST['mes'] == '2') echo 'selected'; ?>>Febrero</option>
                        <option value="3" <?php if (isset($_POST['mes']) && $_POST['mes'] == '3') echo 'selected'; ?>>Marzo</option>
                        <option value="4" <?php if (isset($_POST['mes']) && $_POST['mes'] == '4') echo 'selected'; ?>>Abril</option>
                        <option value="5" <?php if (isset($_POST['mes']) && $_POST['mes'] == '5') echo 'selected'; ?>>Mayo</option>
                        <option value="6" <?php if (isset($_POST['mes']) && $_POST['mes'] == '6') echo 'selected'; ?>>Junio</option>
                        <option value="7" <?php if (isset($_POST['mes']) && $_POST['mes'] == '7') echo 'selected'; ?>>Julio</option>
                        <option value="8" <?php if (isset($_POST['mes']) && $_POST['mes'] == '8') echo 'selected'; ?>>Agosto</option>
                        <option value="9" <?php if (isset($_POST['mes']) && $_POST['mes'] == '9') echo 'selected'; ?>>Septiembre</option>
                        <option value="10" <?php if (isset($_POST['mes']) && $_POST['mes'] == '10') echo 'selected'; ?>>Octubre</option>
                        <option value="11" <?php if (isset($_POST['mes']) && $_POST['mes'] == '11') echo 'selected'; ?>>Noviembre</option>
                        <option value="12" <?php if (isset($_POST['mes']) && $_POST['mes'] == '12') echo 'selected'; ?>>Diciembre</option>
                    </select>

                </div>
                <button type="submit" id="Registro" name="consultar">Consultar</button>
                <button type="button" onclick="window.location.href = 'system.php'" aria-label="Limpiar">
                    <i class="fa-solid fa-trash-can" style="color: #fd0000;"></i>
                </button>

            </div>
    </div>
    </form>

    <?php
    if (isset($_POST['consultar'])) {
        $usuario = $_POST['usuarios'];
        $fecha = $_POST['fecha'];
        $mes = $_POST['mes'];

        $sql = "SELECT * FROM registros WHERE 1"; // Query base para seleccionar todos los registros

        if (!empty($usuario)) {
            $sql .= " AND codigo = '$usuario'";
        }

        if (!empty($fecha)) {
            $sql .= " AND fecha = '$fecha'";
        }

        if (!empty($mes)) {
            $sql .= " AND EXTRACT(MONTH FROM fecha) = '$mes'";
        }

        $sql .= " ORDER BY fecha ASC, hora_inout ASC"; // Ordena los registros por la fecha y la hora

        $consulta = mysqli_query($conn, $sql);
        if (!$consulta) {
            die("Error en la consulta: " . mysqli_error($conn));
        }
    ?>
        <h5 id="Subtitulo">Código de Usuario: <span class='codigo'><?php echo $usuario ?></span></h5>

        <div class="table-responsive">
            <table width="auto" class="table" id="Tabla">
                <thead align="center" class="thead-dark">
                    <tr align="center">
                        <th class="text-center">
                            <h6 class="fw-bold" id="Subtitulo-tabla">Código de Usuario</h6>
                        </th>
                        <th class="text-center">
                            <h6 class="fw-bold" id="Subtitulo-tabla">Nombre</h6>
                        </th>
                        <th class="text-center">
                            <h6 class="fw-bold" id="Subtitulo-tabla">Fecha de marcación</h6>
                        </th>
                        <th class="text-center">
                            <h6 class="fw-bold" id="Subtitulo-tabla">Hora de marcación</h6>
                        </th>
                        <th class="text-center">
                            <h6 class="fw-bold" id="Subtitulo-tabla">Acciones</h6>
                        </th>
                    </tr>
                </thead>
                <tbody align="center">
                    <?php
                    $n = 0;
                    while ($row = mysqli_fetch_array($consulta)) {
                        $n++;
                        // Consulta para obtener el nombre del usuario
                        $codigo_usuario = $row['codigo'];
                        $nombre_usuario_query = mysqli_query($conn, "SELECT usuario FROM usuarios WHERE codigo = '$codigo_usuario'");
                        $nombre_usuario_row = mysqli_fetch_assoc($nombre_usuario_query);
                        $nombre_usuario = $nombre_usuario_row['usuario'];

                        // Cambiar el idioma a español
                        setlocale(LC_TIME, 'es_ES.UTF-8');

                        // Formatear la fecha en el nuevo formato (jueves 10-09-2023)
                        $fechaFormateada = strftime('%A %d-%m-%Y', strtotime($row['fecha']));

                        // Formatear la hora con "a.m." o "p.m."
                        $hora = date('h:i A', strtotime($row['hora_inout']));
                        echo "<tr>";
                        echo "<td class='codigo-usuario'>" . $codigo_usuario . "</td>"; // Código de usuario con clase CSS
                        echo "<td>" . $nombre_usuario . "</td>"; // Nombre de usuario
                        echo "<td class='fecha-marcacion'>" . $fechaFormateada . "</td>"; // Fecha de marcación con clase CSS
                        echo "<td class='hora-marcacion'>" . $hora . "</td>"; // Hora de marcación con clase CSS
                        // Agrega el botón de eliminar aquí dentro de la celda de la tabla
                        echo '<td class="actions">
                            <form method="POST" action="" style="display: inline;">
                                    <input type="hidden" name="eliminar_registro" value="' . $row['id'] . '">
                                <button type="submit" class="btn btn-danger btn-sm" style="width: 70px;" onclick="return confirm(\'¿Estás seguro de eliminar este registro?\');">
                                    <i class="fas fa-trash"></i> Delete
                                </button>
                            </form>

                            <button type="button" class="btn btn-primary btn-sm edit-btn" style="width: 70px;">
                                <i class="fas fa-edit"></i> Update
                            </button>
                                <div class="edit-form" style="display: none;"><br>
                                    <form method="POST" action="" style="display: inline;">
                                        <input type="hidden" name="editar_registro" value="' . $row['id'] . '">
                                        <div class="form-group">
                                            <input type="date" name="nueva_fecha" class="form-control" style="width: 130px;" value="' . $row['fecha'] . '">
                                        </div>
                                        <div class="form-group">
                                            <input type="time" name="nueva_hora" class="form-control" style="width: 130px;" value="' . $row['hora_inout'] . '">
                                        </div>
                                        <button type="submit"  onclick="return confirm(\'¿Estás seguro de guardar los cambios?\');">
                                            Guardar
                                        </button>
                                    </form>
                                </div>
                                </td>';

                        echo "</tr>";
                    }
                    ?>
                    <?php
                    if ($n == 0) {
                        echo "<div class='alert alert-success'>No se han encontrado registros</div>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
        <br><br>
    <?php
    } //end if isset($_POST['consultar'])
    ?>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const editButtons = document.querySelectorAll(".edit-btn");

            editButtons.forEach(function(button) {
                button.addEventListener("click", function() {
                    const editForm = this.nextElementSibling;
                    editForm.style.display = editForm.style.display === "none" ? "block" : "none";
                });
            });
        });
    </script>


    <script>
        function limpiarBusqueda() {
            // Limpiar los campos de selección y fecha
            document.getElementById("selectBox").selectedIndex = 0;
            document.getElementById("fecha").value = '';
            document.getElementById("mes").selectedIndex = 0;

            // Enviar el formulario vacío para actualizar la página
            document.forms["formularioBusqueda"].submit();
        }
    </script>

    <?php
    if (isset($_POST['eliminar_registro'])) {
        $registro_id = $_POST['eliminar_registro'];

        // Preparar la consulta para eliminar el registro
        $sql_delete = "DELETE FROM registros WHERE id = ?";

        // Preparar la sentencia
        $stmt = mysqli_prepare($conn, $sql_delete);

        // Vincular parámetros
        mysqli_stmt_bind_param($stmt, "i", $registro_id);

        // Ejecutar la sentencia
        $resultado_delete = mysqli_stmt_execute($stmt);

        // Verificar si la eliminación fue exitosa
        if ($resultado_delete) {
            echo "<script>alert('El registro se eliminó correctamente');</script>";
            // Redirigir a la página principal o a donde desees después de eliminar el registro
            echo "<script>window.location.href = 'system.php';</script>";
            exit();
        } else {
            echo "<script>alert('Hubo un error al eliminar el registro');</script>";
            // Manejar el error de eliminación, por ejemplo, mostrar un mensaje de error o redirigir a una página de error
        }
    }
    ?>

    <?php
    if (isset($_POST['editar_registro'])) {
        $registro_id = $_POST['editar_registro'];
        $nueva_fecha = $_POST['nueva_fecha'];
        $nueva_hora = $_POST['nueva_hora'];

        // Obtener la fecha y la hora existentes del registro
        $consulta_registro = mysqli_query($conn, "SELECT fecha, hora_inout FROM registros WHERE id = $registro_id");
        $registro_actual = mysqli_fetch_assoc($consulta_registro);
        $fecha_existente = $registro_actual['fecha'];
        $hora_existente = $registro_actual['hora_inout'];

        // Verificar si hay cambios en la fecha o en la hora
        if ($nueva_fecha != $fecha_existente || $nueva_hora != $hora_existente) {
            // Preparar la consulta para actualizar el registro
            $sql_update = "UPDATE registros SET ";
            $params = array();
            if ($nueva_fecha != $fecha_existente) {
                $sql_update .= "fecha = ?, ";
                $params[] = $nueva_fecha;
            }
            if ($nueva_hora != $hora_existente) {
                $sql_update .= "hora_inout = ?, ";
                $params[] = $nueva_hora;
            }
            $sql_update = rtrim($sql_update, ", ") . " WHERE id = ?";

            // Preparar la sentencia
            $stmt = mysqli_prepare($conn, $sql_update);

            // Vincular parámetros
            $types = str_repeat("s", count($params)) . "i";
            $bind_params = array_merge(array($stmt, $types), $params, array($registro_id));
            call_user_func_array('mysqli_stmt_bind_param', $bind_params);

            // Ejecutar la sentencia
            $resultado_update = mysqli_stmt_execute($stmt);

            // Verificar si la actualización fue exitosa
            if ($resultado_update) {
                echo "<script>alert('El registro se actualizó correctamente');</script>";
                // Redirigir a la página principal o a donde desees después de actualizar el registro
                echo "<script>window.location.href = 'system.php';</script>";
                exit();
            } else {
                echo "<script>alert('Hubo un error al actualizar el registro');</script>";
                // Manejar el error de actualización, por ejemplo, mostrar un mensaje de error o redirigir a una página de error
            }
        } else {
            echo "<script>alert('No se han realizado cambios en la fecha ni en la hora');</script>";
        }
    }
    ?>



    <script src="../script.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js" integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous"></script>
    </div>
</body>

</html>